 function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('#E42B1D');
  fill('#03A9F4');
  circle(200, 200, 300); // rosto
  fill('white');
  circle(150, 150, 60); // olho esquerdo
  circle(250, 150, 60); // olho direito
  line(150, 270, 250, 235);
  fill('#3F51B5');
  triangle(200, 180, 170, 220, 220, 220);
  line(123, 115, 178, 113);
  line(225, 116, 279, 106);
  circle(150, 150, 10);
  circle(250, 150, 10);
  
  if(mouseIsPressed){
     console.log(mouseX, mouseY);
     }
}